# 保质期管家 V1.0

本工程面向 Android 手机，数据保存在本地 Room 数据库。

## 云端构建 APK（不需要 Android Studio）

1. 在 GitHub 新建一个空的 Repository。
2. 把本工程 ZIP 解压后，把里面**所有文件和文件夹**上传到仓库根目录。
3. 进入仓库的 **Actions**，选择 **Build Android APK**。
4. 点击 **Run workflow**。
5. 构建成功后进入该次运行页面，在 **Artifacts** 下载 `BaoZhiQi-debug-apk`。
6. 解压得到 `app-debug.apk`，传到安卓手机后直接安装。

工作流使用 GitHub-hosted runner、JDK 17 和 Gradle 8.11.1；不需要在本机安装 Android Studio。
