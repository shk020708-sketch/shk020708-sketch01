package com.knightly.baozhiqi
import android.graphics.Typeface
import android.view.*
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
class ItemAdapter(private val onClick: (Item)->Unit): RecyclerView.Adapter<ItemAdapter.VH>() {
    private var data = listOf<Item>()
    fun submit(v: List<Item>) { data=v; notifyDataSetChanged() }
    class VH(v: View): RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(1)
        val sub: TextView = v.findViewById(2)
    }
    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
        val box = LinearLayout(p.context).apply { orientation=LinearLayout.VERTICAL; setPadding(16,18,16,18) }
        val a=TextView(p.context).apply { id=1; textSize=18f; typeface=Typeface.DEFAULT_BOLD }
        val b=TextView(p.context).apply { id=2; textSize=14f }
        box.addView(a); box.addView(b); return VH(box)
    }
    override fun onBindViewHolder(h: VH, i: Int) {
        val x=data[i]; val d=daysLeft(x.expiryDate)
        h.title.text=x.name
        h.sub.text="到期：${fmt(x.expiryDate)}    "+when { d<0 -> "已过期 ${-d} 天"; d==0L -> "今天到期"; d<=30 -> "还有 $d 天"; else -> "正常" }
        h.itemView.setOnClickListener { onClick(x) }
    }
    override fun getItemCount()=data.size
}
