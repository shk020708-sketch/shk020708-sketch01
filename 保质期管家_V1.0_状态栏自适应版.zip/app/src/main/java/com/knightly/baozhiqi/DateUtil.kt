package com.knightly.baozhiqi
import java.time.*
import java.time.temporal.ChronoUnit
fun expiryDate(production: Long, months: Int): Long =
    Instant.ofEpochMilli(production).atZone(ZoneId.systemDefault()).toLocalDate()
        .plusMonths(months.toLong()).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
fun daysLeft(expiry: Long): Long =
    ChronoUnit.DAYS.between(LocalDate.now(), Instant.ofEpochMilli(expiry).atZone(ZoneId.systemDefault()).toLocalDate())
fun fmt(ms: Long): String =
    Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate().toString()
