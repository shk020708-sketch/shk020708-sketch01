package com.knightly.baozhiqi
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "items")
data class Item(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val productionDate: Long,
    val shelfMonths: Int,
    val expiryDate: Long,
    val remindDays: Int
)
