package com.knightly.baozhiqi
import androidx.room.*
import kotlinx.coroutines.flow.Flow
@Dao
interface ItemDao {
    @Query("SELECT * FROM items ORDER BY expiryDate ASC")
    fun observeAll(): Flow<List<Item>>
    @Insert suspend fun insert(item: Item): Long
    @Update suspend fun update(item: Item)
    @Delete suspend fun delete(item: Item)
    @Query("DELETE FROM items") suspend fun deleteAll()
}
