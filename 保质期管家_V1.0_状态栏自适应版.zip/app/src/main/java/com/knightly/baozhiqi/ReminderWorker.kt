package com.knightly.baozhiqi

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.flow.first

class ReminderWorker(app: android.content.Context, params: WorkerParameters) :
    CoroutineWorker(app, params) {

    override suspend fun doWork(): Result {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) return Result.success()

        val list = AppDb.get(applicationContext).itemDao().observeAll().first()
        val nm = applicationContext.getSystemService(NotificationManager::class.java)

        if (android.os.Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(
                    "expiry",
                    "保质期提醒",
                    NotificationManager.IMPORTANCE_DEFAULT
                )
            )
        }

        list.filter {
            val d = daysLeft(it.expiryDate)
            d >= 0 && d <= it.remindDays
        }.forEach {
            val d = daysLeft(it.expiryDate)
            val text = if (d == 0L) "${it.name} 今天到期" else "${it.name} 将在 $d 天后到期"
            nm.notify(
                it.id.toInt(),
                NotificationCompat.Builder(applicationContext, "expiry")
                    .setSmallIcon(R.drawable.ic_notification)
                    .setContentTitle("保质期提醒")
                    .setContentText(text)
                    .setAutoCancel(true)
                    .build()
            )
        }
        return Result.success()
    }
}
