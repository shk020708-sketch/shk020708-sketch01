package com.knightly.baozhiqi

import android.Manifest
import android.app.DatePickerDialog
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.work.*
import java.time.*
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var dao: ItemDao
    private lateinit var adapter: ItemAdapter
    private var selectedDate = LocalDate.now()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dao = AppDb.get(this).itemDao()
        requestNotification()
        setupPeriodicReminder()
        buildUi()
    }

    private fun requestNotification() {
        if (Build.VERSION.SDK_INT >= 33)
            registerForActivityResult(ActivityResultContracts.RequestPermission()) {}.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    private fun setupPeriodicReminder() {
        val req = PeriodicWorkRequestBuilder<ReminderWorker>(1, TimeUnit.DAYS)
            .setInitialDelay(1, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "expiry-reminder", ExistingPeriodicWorkPolicy.UPDATE, req
        )
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24,24,24,16) }
        val title = TextView(this).apply { text = "保质期管家"; textSize = 28f; setPadding(0,0,0,16) }
        val add = Button(this).apply { text = "＋ 添加物品"; setOnClickListener { showAddDialog() } }
        val list = RecyclerView(this).apply { layoutManager = LinearLayoutManager(this@MainActivity) }
        adapter = ItemAdapter { item -> showEditDialog(item) }
        list.adapter = adapter
        root.addView(title); root.addView(add)
        root.addView(list, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        lifecycleScope.launch {
            dao.observeAll().collect { adapter.submit(it) }
        }
    }

    private fun showAddDialog(existing: Item? = null) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20,10,20,0) }
        val name = EditText(this).apply { hint = "物品名称"; setText(existing?.name ?: "") }
        val months = EditText(this).apply { hint = "保质期（月）"; inputType = 2; setText(existing?.shelfMonths?.toString() ?: "") }
        val remind = EditText(this).apply { hint = "提前提醒天数"; inputType = 2; setText(existing?.remindDays?.toString() ?: "7") }
        val dateBtn = Button(this).apply { text = "生产日期：${existing?.let { fmt(it.productionDate) } ?: selectedDate}" }
        dateBtn.setOnClickListener {
            DatePickerDialog(this@MainActivity, { _, y,m,d ->
                selectedDate = LocalDate.of(y,m+1,d); dateBtn.text = "生产日期：$selectedDate"
            }, selectedDate.year, selectedDate.monthValue-1, selectedDate.dayOfMonth).show()
        }
        box.addView(name); box.addView(dateBtn); box.addView(months); box.addView(remind)
        AlertDialogCompat(this, if (existing == null) "添加物品" else "编辑物品", box) {
            val n = name.text.toString().trim()
            val mo = months.text.toString().toIntOrNull()
            val rd = remind.text.toString().toIntOrNull()
            if (n.isEmpty() || mo == null || mo < 0 || rd == null || rd < 0) {
                Toast.makeText(this, "请填写正确的信息", Toast.LENGTH_SHORT).show()
            } else {
                val prod = selectedDate.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                val exp = expiryDate(prod, mo)
                lifecycleScope.launch {
                    if (existing == null) {
                        dao.insert(Item(name=n, productionDate=prod, shelfMonths=mo, expiryDate=exp, remindDays=rd))
                    } else {
                        dao.update(existing.copy(name=n, productionDate=prod, shelfMonths=mo, expiryDate=exp, remindDays=rd))
                    }
                }
            }
        }.show()
    }

    private fun showEditDialog(item: Item) {
        selectedDate = Instant.ofEpochMilli(item.productionDate).atZone(ZoneId.systemDefault()).toLocalDate()
        showAddDialog(item)
    }
}

private class AlertDialogCompat(
    private val activity: AppCompatActivity, private val title: String,
    private val view: android.view.View, private val onOk: () -> Unit
) {
    fun show() {
        androidx.appcompat.app.AlertDialog.Builder(activity).setTitle(title).setView(view)
            .setNegativeButton("取消", null).setPositiveButton("保存") { _, _ -> onOk() }.show()
    }
}
